$(document).ready(function(){

  $(".btn_Synthsis,.btn_State,.btn_Skil,.btn_Character,.btn_Look").click(function(){
    $(".info *").remove();
    var userName = $("#userName").val();
    var userAge = $("#userAge").val();
    var userGender = $("#userGender").val();
    if(!userName){
      alert("이름을 입력해요!");
    }
    if(!userAge){
      alert("나이를 빼먹었어요!");
    }
    if(!userGender){
      alert("성별을 입력해주세요!");
    }
    if(userName && userAge && userGender){
      var person = new Person(userName,userAge,userGender);
      var btn_class = $(this).attr("class");
      if(btn_class == "btn_State"){
        person.showState();
      }else if(btn_class == "btn_Skil"){
        person.showSkil();
      }else if(btn_class == "btn_Character"){
        person.showCharacter();
      }else if(btn_class == "btn_Look"){
        person.showLook();
      }else if(btn_class == "btn_Synthsis"){
        person.showSynthesis();
      }
    }
  });

});
