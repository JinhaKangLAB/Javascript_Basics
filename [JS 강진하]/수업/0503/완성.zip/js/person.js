function Person(name,age,gender){
  this.name = name;
  this.age = age;
  this.gender = gender;
  this.getName = function(){
    return this.name;
  }
  this.getAge = function(){
    return this.age;
  }
  this.getGender = function(){
    return this.gender;
  }
  this.skil = function(){
    var skilArray = ["낮에 졸기","수업시간에 명상하기","걷다가 졸기","헛소리 하기","갑자기 웃기","갑자기 울기","술먹고 헤롱대기","영화관 기웃거리기","사지도 않을 물건 구경하기","밤에 안자기","자다가 헛소리하기","로또 1등되기"];
    var result = Math.floor(Math.random()*skilArray.length);
    return skilArray[result];
  }
  this.character = function(){
    if(this.age < 25){
      return "순수함";
    }else if(this.age < 35){
      return "살짝 때묻음";
    }else if(this.age < 45){
      return "꼰대심증가력";
    }else{
      return "슈퍼꼰대력";
    }
  }
  this.look = function(){
    if(gender == "여자"){
      if(this.age < 25){
        return "귀여움";
      }else if(this.age < 35){
        return "털털미";
      }else if(this.age < 45){
        return "성숙미";
      }else{
        return "푸석미";
      }
    }else{
      if(this.age < 25){
        return "샤프함";
      }else if(this.age < 35){
        return "건강미";
      }else if(this.age < 45){
        return "노쇄미";
      }else{
        return "시들미";
      }
    }
  }
  this.showState = function(){
    $(".info").append("<h2>당신의 이름은 <b>"+this.getName()+"</b>입니다.</h2>");
    $(".info").append("<p>당신은 올해 <b>"+this.getAge()+"</b>살 이고</p>");
    $(".info").append("<p><b>"+this.getGender()+"</b>입니다.</p>")
  }
  this.showSkil = function(){
    $(".info").append("<p>당신의 주특기는 <b>"+this.skil()+"</b>입니다.</p>");
  }
  this.showCharacter = function(){
    $(".info").append("<p>당신은 <b>"+this.character()+"</b>이 돋보입니다.</p>")
  }
  this.showLook = function(){
    $(".info").append("<p>당신은 나이에 맞게 <b>"+this.look()+"</b>가(이) 굉장히 돋보이고 있습니다.</p>");
  }
  this.showSynthesis = function(){
    $(".info").append("<h2>당신의 이름은 <b>"+this.getName()+"</b>입니다.</h2>");
    $(".info").append("<p>나이를 먹고 먹어서 드디어 올해 <b>"+this.getAge()+"</b>살이 되었습니다.</p>");
    $(".info").append("<p><b>"+this.getGender()+"</b>의 성별을 가졌으며,</p>");
    $(".info").append("<p>주특기는 틈만나면 <b>"+this.skil()+"</b>입니다.</p>");
    $(".info").append("<p>나이에 맞게 당신은 <b>"+this.character()+"</b>이 돋보이는 사람입니다.</p>");
    $(".info").append("<p>역시나 올해 <b>"+this.getAge()+"</b>살 인만큼 <b>"+this.look()+"</b>가(이) 굉장히 돋보이고 있습니다.</p>");
  }
}
